package com.clocksheet;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddEmpSev
 */
@WebServlet("/AddEmpSev")
public class AddEmpSev extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String url = "jdbc:mysql://localhost:3306/clocksheet";
    private static final String conuser = "root";
    private static final String conPassword = "";
    private static String lastEmpQuery = "select max(EmpID) as EmpID from clocksheet.employee order by EmpID desc";
	//database authentication values

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEmpSev() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, conuser, conPassword);

            PreparedStatement preparedStatement = connection.prepareStatement(lastEmpQuery);

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                
    			String name =rs.getString("EmpID");
    			req.setAttribute("label", name);
    	                RequestDispatcher rd = req.getRequestDispatcher("AddEmpTest.jsp");
    	                rd.forward(req,response);
                
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
