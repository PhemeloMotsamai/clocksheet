package com.clocksheet;

import java.sql.*;

public class DatabaseHelper {
	

    
	/*                                              Start of SQL Statements                                                       */	
	
	private static final String readEmployees = "Select EmpID,FName,SName,department.DerpartName, employee.Telephone as \"Employee  telephone\", department.Telephone as \"Department Telephone\" \n"
            + "from clocksheet.employee inner join \n"
            + "clocksheet.department\n"
            + "on clocksheet.employee.Department =clocksheet.department.DepartId\n"
            + "order by EmpID asc";
    
    
	private static final String loginQuery = "SELECT * FROM clocksheet.employee where EmpID = ? and Password =? and  Department = 6;";
	
	
	/*                                              End of SQL Statements                                                       */
	
	
	/*                                              Start of Connection Variables SQL Statements                                      */
	
    private static final String url = "jdbc:mysql://localhost:3306/clocksheet";
    private static final String conuser = "root";
    private static final String conPassword = "";
    
	/*                                              End of Connection Variables SQL Statements                                        */
    
    
    
    // Login Database logic
    public boolean checkUser(String username, String password) {
        boolean result = false;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, conuser, conPassword);

            //Prepared statement 
            PreparedStatement Ps = connection.prepareStatement(loginQuery);
            Ps.setString(1, username);
            Ps.setString(2, password);
            	
            ResultSet rs = Ps.executeQuery();

            if (rs.next())  {
            	result = true;
            	
                return result;

            }
            
            else {
            	result = false;
            }

            connection.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    /*
    public  void viewEmployeesSQL() throws SQLException, ClassNotFoundException {

        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, conuser, conPassword);

            PreparedStatement preparedStatement = connection.prepareStatement(readEmployees);

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
            	empObj.empID.add(rs.getString("EmpID"));
            	empObj.Fname.add(rs.getString("FName"));
            	empObj.Sname.add(rs.getString("SName"));
            	empObj.DerpartName.add(rs.getString("department.DerpartName"));
            	empObj.empTelephone.add(rs.getString("Employee  telephone"));
            	empObj.depTelephone.add(rs.getString("Department Telephone"));

            }
            
Select EmpID,FName,SName,department.DerpartName, employee.Telephone as "Employee  telephone", department.Telephone as "Department Telephone" 
from clocksheet.employee inner join 
clocksheet.department
on clocksheet.employee.Department =clocksheet.department.DepartId
order by EmpID asc

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    */
}
