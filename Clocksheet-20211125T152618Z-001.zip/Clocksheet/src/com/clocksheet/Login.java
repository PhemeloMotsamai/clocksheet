package com.clocksheet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    ArrayList<String> admin  = new ArrayList<String>();
    DatabaseHelper dataObj = new DatabaseHelper();
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//res.getWriter().append("Served at: ").append(req.getContextPath());
		
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		
		// admin credentials 
		admin.add(req.getParameter("username"));
		admin.add(req.getParameter("password"));
		
		if (dataObj.checkUser(username, password)) {
			HttpSession session = req.getSession();
			session.setAttribute("username", username);
			res.sendRedirect("Dashboard.jsp");
		}
		
		else {
	 
			res.sendRedirect("index.jsp");
			//PrintWriter out = res.getWriter();
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
